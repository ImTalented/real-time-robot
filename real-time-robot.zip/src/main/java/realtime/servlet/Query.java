package realtime.servlet;

import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import realtime.db.DBConnect;
//import realtime.vo.robotdata;
import realtime.dao.*;
//import realtime.dao.impl.DataDAOImpl;

public class Query extends HttpServlet{

	 private static final long serialVersionUID = 1L;

	 public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		 	HttpSession session = request.getSession();
		 	String robotid2 = (String)session.getAttribute("robotID");	
		 	int robotid = Integer.parseInt(robotid2);
			String[][] temp = new String[100][4];
			int num = 0;
			String sql = "select * from record where robotID = ? order by time desc";
	        PreparedStatement pstmt = null ;   
	        DBConnect dbc = null;   
	        // 下面是针对数据库的具体操作   
	        try{   
	            // 连接数据库   
	            dbc = new DBConnect() ;   
	            pstmt = dbc.getConnection().prepareStatement(sql) ; 
	            pstmt.setInt(1,robotid) ;   
	            // 进行数据库查询操作   
	            ResultSet rs = pstmt.executeQuery();
	            while(rs.next()){  
	            	temp[num][0] = rs.getString(3); 
	            	temp[num][1] = rs.getString(4);
	            	temp[num][2] = rs.getString(5);
//	            	测试用
//	                System.out.print(temp[num][0]);
//	                System.out.print(temp[num][1]);
	            	num = num + 1;
	            }   
	            rs.close() ; 
	            pstmt.close() ;   
	        }catch (SQLException e){   
	            System.out.println(e.getMessage());   
	        }finally{   
	            // 关闭数据库连接   
	            dbc.close() ;   
	        }   

	        	request.setAttribute("mes",temp);
	        	request.setAttribute("num",num);
	        	request.setAttribute("name",robotid);
	        	request.getRequestDispatcher("query2.jsp").forward(request,response);
			}
	 
	 public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
//			此处要写调用当前session的username   session.setAttribute("username", userinfo.getUsername());   
			//String username = session.getAttribute("username");  
			int robotid = Integer.parseInt(request.getParameter("robotID"));
			String[][] temp = new String[100][4];
			int num = 0;
			String sql = "select * from record where robotID = ? order by time desc";
	        PreparedStatement pstmt = null ;   
	        DBConnect dbc = null;   
	        // 下面是针对数据库的具体操作   
	        try{   
	            // 连接数据库   
	            dbc = new DBConnect() ;   
	            pstmt = dbc.getConnection().prepareStatement(sql) ; 
	            pstmt.setInt(1,robotid) ;   
	            // 进行数据库查询操作   
	            ResultSet rs = pstmt.executeQuery();
	            while(rs.next()){  
	            	temp[num][0] = rs.getString(3); 
	            	temp[num][1] = rs.getString(4);
	            	temp[num][2] = rs.getString(5);
//	            	测试用
//	                System.out.print(temp[num][0]);
//	                System.out.print(temp[num][1]);
	            	num = num + 1;
	            }   
	            rs.close() ; 
	            pstmt.close() ;   
	        }catch (SQLException e){   
	            System.out.println(e.getMessage());   
	        }finally{   
	            // 关闭数据库连接   
	            dbc.close() ;   
	        }   

	        	request.setAttribute("mes",temp);
	        	request.setAttribute("num",num);
	        	request.setAttribute("name",robotid);
	        	request.getRequestDispatcher("query2.jsp").forward(request,response);
	        	
 	
			}
	 
	 
	 
	 
}