package realtime.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import realtime.dao.UserDAO;
import realtime.dao.impl.UserDAOImpl;
import realtime.vo.UserInfo;


public class UserLoginServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res)
	throws IOException, ServletException{
	}
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException{
		
		System.out.print(1111);
		
		
		UserInfo userinfo = new UserInfo();
		userinfo.setUsername(req.getParameter("username"));
		userinfo.setPassword(req.getParameter("password"));
		
		UserDAO dao = new UserDAOImpl() ;
		int flag=0;
		try{
			flag=dao.queryByUserInfo(userinfo);
		}catch(Exception e) {
			//TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(flag==1) {
			HttpSession session=req.getSession();
			session.setAttribute("username",userinfo.getUsername());
			res.sendRedirect("./realtime.jsp");
		}else {
			res.sendRedirect("./error.jsp");
		}
	}
}
