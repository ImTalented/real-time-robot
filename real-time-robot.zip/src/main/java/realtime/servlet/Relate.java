package realtime.servlet;

import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import realtime.db.DBConnect;
//import realtime.vo.robotdata;
import realtime.dao.*;
//import realtime.dao.impl.DataDAOImpl;

public class Relate extends HttpServlet{

	 private static final long serialVersionUID = 1L;

	 public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
//			
			}
	 
	 public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
//			此处要写调用当前session的username   session.setAttribute("username", userinfo.getUsername());   
			//String username = session.getAttribute("username");  
		 	HttpSession session = request.getSession();
			session.setAttribute("robotID",request.getParameter("robotID"));
			response.sendRedirect("./realtime.jsp");
			}
	 
	 
	 
	 
}