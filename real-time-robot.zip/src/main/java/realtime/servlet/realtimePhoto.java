package realtime.servlet;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;



import realtime.db.DBConnect;


public class realtimePhoto extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException{
//		此处要写调用当前session的username   session.setAttribute("username", userinfo.getUsername());   
		
		//要两个一起才能得session
		HttpSession session = request.getSession();
		String username = (String)session.getAttribute("username");  
		
		
		String[][] temp = new String[100][2];
		int num = 0;
		String sql = "select * from photo where username = ? order by time desc";
        PreparedStatement pstmt = null ;   
        DBConnect dbc = null;   
        // 下面是针对数据库的具体操作   
        try{   
            // 连接数据库   
            dbc = new DBConnect() ;   
            pstmt = dbc.getConnection().prepareStatement(sql) ; 
            pstmt.setString(1,username) ;   
            // 进行数据库查询操作   
            ResultSet rs = pstmt.executeQuery();
            while(rs.next()){  
            	temp[num][0] = rs.getString(3); 
            	temp[num][1] = rs.getString(4); 
//            	测试用
//                System.out.print(temp[num][0]);
//                System.out.print(temp[num][1]);
            	num = num + 1;
            }   
            rs.close() ; 
            pstmt.close() ;   
        }catch (SQLException e){   
            System.out.println(e.getMessage());   
        }finally{   
            // 关闭数据库连接   
            dbc.close() ;   
        }   

        	request.setAttribute("mes",temp);
        	request.setAttribute("num",num);
        	request.getRequestDispatcher("realtimephoto.jsp").forward(request,response);
        	
        	
        	
        	
        	
		}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
		    throws IOException, ServletException{
		
		 }
	
}
