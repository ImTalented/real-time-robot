package realtime.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import realtime.dao.UserDAO;
import realtime.dao.impl.UserDAOImpl2;
import realtime.vo.UserInfo;

public class UserRegisterServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException{
			}
			public void doPost(HttpServletRequest req, HttpServletResponse res)
					throws IOException, ServletException{
				UserInfo userinfo = new UserInfo();
				userinfo.setUsername(req.getParameter("username"));
				userinfo.setPassword(req.getParameter("password"));
				userinfo.setPasswordagn(req.getParameter("passwordagn"));
				userinfo.setTelephone(req.getParameter("telephone"));
				
				UserDAO dao = new UserDAOImpl2() ;
				int flag=0;
				try{
					flag=dao.queryByUserInfo(userinfo);
				}catch(Exception e) {
					//TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(flag==1) {
					HttpSession session=req.getSession();
					session.setAttribute("username",userinfo.getUsername());
					res.sendRedirect("./false.jsp");
				}else if(flag==2){
					res.sendRedirect("./false2.jsp");
				}else{
					res.sendRedirect("./success.jsp");
				}
			}
}
