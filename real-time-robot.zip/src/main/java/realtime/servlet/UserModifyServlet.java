package realtime.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import realtime.dao.UserDAO;
import realtime.dao.impl.UserDAOImpl3;
import realtime.vo.UserInfo;

public class UserModifyServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException{
			}
			public void doPost(HttpServletRequest req, HttpServletResponse res)
					throws IOException, ServletException{
				UserInfo userinfo = new UserInfo();
				userinfo.setUsername(req.getParameter("username"));
				userinfo.setTelephone(req.getParameter("telephone"));
				userinfo.setNewpassword(req.getParameter("newpassword"));
				
				UserDAO dao = new UserDAOImpl3() ;
				int flag=0;
				try{
					flag=dao.queryByUserInfo(userinfo);
				}catch(Exception e) {
					//TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(flag==1) {
					HttpSession session=req.getSession();
					session.setAttribute("username",userinfo.getUsername());
					res.sendRedirect("./success1.jsp");
				}else {
					res.sendRedirect("./error1.jsp");
				}
			}
}
