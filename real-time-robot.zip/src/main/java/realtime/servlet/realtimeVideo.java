package realtime.servlet;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;



import realtime.db.DBConnect;


public class realtimeVideo extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException{
//		此处要写调用当前session的username   session.setAttribute("username", userinfo.getUsername());   
		//String username = session.getAttribute("username");  
		//要两个一起才能得session
		HttpSession session = request.getSession();
		String username = (String)session.getAttribute("username");   //这应该获取机器人ID
		String[] temp = new String[2];
		int num = 1;
		String sql = "select * from video order by time desc";  //这应该改成机器人ID，按照时间倒序输出，所得视频为最新时间
        PreparedStatement pstmt = null ;   
        DBConnect dbc = null;   
        // 下面是针对数据库的具体操作   
        try{   
            // 连接数据库   
            dbc = new DBConnect() ;   
            pstmt = dbc.getConnection().prepareStatement(sql) ;    
            // 进行数据库查询操作   
            ResultSet rs = pstmt.executeQuery();
            	rs.next();
            	temp[0] = rs.getString(3); 
            	temp[1] = rs.getString(4); 
//            	测试用
//                System.out.print(temp[num][0]);
//                System.out.print(temp[num][1]);

            rs.close() ; 
            pstmt.close() ;   
        }catch (SQLException e){   
            System.out.println(e.getMessage());   
        }finally{   
            // 关闭数据库连接   
            dbc.close() ;   
        }   

        	request.setAttribute("mes",temp);
        	request.setAttribute("num",num);
        	request.getRequestDispatcher("realvideo.jsp").forward(request,response);
        	
        	
        	
        	
        	
		}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
		    throws IOException, ServletException{
		
		 }
	
}
