package realtime.dao;

import realtime.vo.*;

public interface UserDAO {
	public int queryByUserInfo(UserInfo userinfo) throws Exception;
}
