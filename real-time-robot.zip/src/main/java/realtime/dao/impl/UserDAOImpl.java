package realtime.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import realtime.dao.UserDAO;
import realtime.db.DBConnect;
import realtime.vo.UserInfo;

public class UserDAOImpl implements UserDAO {

	@Override
	public int queryByUserInfo(UserInfo userinfo) throws Exception {
		// TODO Auto-generated method stub
		int flag=0;
		String sql = "select * from userinfo where username=?";
		PreparedStatement pstmt = null;
		DBConnect dbc = null;
		
		//下面是针对数据库的具体操作
		try {
			//连接数据库
			dbc = new DBConnect();
			pstmt = dbc.getConnection().prepareStatement(sql);
			pstmt.setString(1, userinfo.getUsername());
			//进行数据库查询操作
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				//查询出内容，将其与用户提交的内容对比
				if(rs.getString("password").equals(userinfo.getPassword())) {
					flag = 1;
				}
			}
			rs.close();
			pstmt.close();
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}finally {
			//关闭数据库 连接
			dbc.close();
		}
		return flag;
	}
}