package realtime.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import realtime.dao.UserDAO;
import realtime.db.DBConnect;
import realtime.vo.UserInfo;

public class UserDAOImpl3 implements UserDAO {

	@Override
	public int queryByUserInfo(UserInfo userinfo) throws Exception {
		// TODO Auto-generated method stub
		int flag = 0;
		String selectQuery = "select * from userinfo where username=?";
		String modifyQuery = "UPDATE userinfo SET password=? WHERE username=?";
		PreparedStatement selectStatement = null;
        PreparedStatement modifyStatement = null;
		DBConnect dbc = null;
		
		//下面是针对数据库的具体操作
		try {
			//连接数据库
			dbc = new DBConnect();
			selectStatement = dbc.getConnection().prepareStatement(selectQuery);
			selectStatement.setString(1, userinfo.getUsername());
			//进行数据库查询操作
			ResultSet rs = selectStatement.executeQuery();
			while(rs.next()) {
				if(rs.getString("telephone").equals(userinfo.getTelephone())) {
					flag = 1;
				}
			}
            if(flag==1) {
				modifyStatement = dbc.getConnection().prepareStatement(modifyQuery);
				modifyStatement.setString(1, userinfo.getNewpassword());
				modifyStatement.setString(2, userinfo.getUsername());
				modifyStatement.executeUpdate();
			}
			rs.close();
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}finally {
			try {
	                if (selectStatement != null) {
	                    selectStatement.close();
	                }
	                if (modifyStatement != null) {
	                    modifyStatement.close();
	                }
	            } catch (SQLException e) {
	                System.out.println(e.getMessage());
	            }
			//关闭数据库 连接
			dbc.close();
		}
		return flag;
	}

}
