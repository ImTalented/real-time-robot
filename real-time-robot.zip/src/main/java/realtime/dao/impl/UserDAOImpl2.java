package realtime.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import realtime.dao.UserDAO;
import realtime.db.DBConnect;
import realtime.vo.UserInfo;

public class UserDAOImpl2 implements UserDAO {

	@Override
	public int queryByUserInfo(UserInfo userinfo) throws Exception {
		// TODO Auto-generated method stub
		int flag=0;
		String selectQuery = "select * from userinfo where username=?";
		String insertQuery = "INSERT INTO userinfo (username, password,telephone) VALUES(?, ?, ?)";
		PreparedStatement selectStatement = null;
        PreparedStatement insertStatement = null;
		DBConnect dbc = null;
		
		//下面是针对数据库的具体操作
		try {
			//连接数据库
			dbc = new DBConnect();
			selectStatement = dbc.getConnection().prepareStatement(selectQuery);
			selectStatement.setString(1, userinfo.getUsername());
			//进行数据库查询操作
			ResultSet rs = selectStatement.executeQuery();
            if (rs.next()) {
                flag = 1;
            } else if (userinfo.getPassword().equals(userinfo.getPasswordagn())) {
                flag = 0;
                insertStatement = dbc.getConnection().prepareStatement(insertQuery);
                insertStatement.setString(1, userinfo.getUsername());
                insertStatement.setString(2, userinfo.getPassword());
                insertStatement.setString(3, userinfo.getTelephone());
                insertStatement.executeUpdate();
            } else {
                flag = 2;
            }

			rs.close();
		}catch(SQLException e) {
			System.out.println(e.getMessage());
		}finally {
			try {
	                if (selectStatement != null) {
	                    selectStatement.close();
	                }
	                if (insertStatement != null) {
	                    insertStatement.close();
	                }
	            } catch (SQLException e) {
	                System.out.println(e.getMessage());
	            }
			//关闭数据库 连接
			dbc.close();
		}
		return flag;
	}

}
