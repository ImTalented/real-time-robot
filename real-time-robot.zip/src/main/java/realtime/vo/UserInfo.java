package realtime.vo;

public class UserInfo {

	private String username;
	private String password;
	private String passwordagn;
	private String telephone;
	private String newpassword;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username=username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password=password;
	}
	public String getPasswordagn() {
		return passwordagn;
	}
	public void setPasswordagn(String passwordagn) {
		this.passwordagn = passwordagn;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getNewpassword() {
		return newpassword;
	}
	public void setNewpassword(String newpassword) {
		this.newpassword = newpassword;
	}
	
}
