import os
import time
import mysql.connector
from PIL import Image
from datetime import datetime
import random

# 获取当前目录
current_directory = r'image\photo\detected'

# 配置数据库连接
db_config = {
    'host': 'localhost',  # 数据库主机
    'user': 'root',       # 数据库用户名
    'password': 'fsh12345',  # 数据库密码
    'database': 'javawebdb'  # 数据库名
}

# 初始化文件数量
num = -1;

for i in range(1000000):
    time.sleep(1)

    # 获取目录下的文件列表
    file_list = os.listdir(current_directory)
    # 统计文件个数
    file_count = len(file_list)

    if file_count != num:
        num = file_count
        try:
            # 建立数据库连接
            conn = mysql.connector.connect(**db_config)
            cursor = conn.cursor()

            # 遍历当前目录下的文件
            for filename in os.listdir(current_directory):
                if filename.endswith(('.jpg', '.jpeg', '.png', '.bmp', '.gif')):
                    file_path = os.path.join(current_directory, filename)
                    # 查询数据库中是否已存在相同的图片
                    sql_check = "SELECT COUNT(*) FROM record WHERE src = %s"
                    val_check = (file_path.replace('\\', '/'),)
                    cursor.execute(sql_check, val_check)
                    result = cursor.fetchone()

                    if result[0] == 0:
                        try:
                            # 打开图片并获取创建时间
                            with Image.open(file_path) as img:
                                created_time = os.path.getctime(file_path)
                                created_time = datetime.fromtimestamp(created_time).strftime('%Y-%m-%d %H:%M:%S')
                                file_path = file_path.replace('\\', '/')


                                a = random.randint(270, 400)
                                b = a / 10

                                #插入数据到数据库
                                sql = "INSERT INTO record (robotID,treasureName, time, src) VALUES (%s, %s, %s ,%s)"
                                val = (222, 'Object', b, file_path)
                                cursor.execute(sql, val)
                                conn.commit()

                                print(f'文件名: {filename}')
                                print(f'绝对路径: {file_path}')
                                print(f'创建时间: {created_time}')
                        except Exception as e:
                            print(f'无法处理文件 {filename}: {str(e)}')

        except mysql.connector.Error as err:
            print(f'数据库错误: {err}')
        finally:
            # 关闭数据库连接
            if conn.is_connected():
                cursor.close()
                conn.close()




