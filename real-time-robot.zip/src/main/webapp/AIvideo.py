from ultralytics import YOLO
import cv2
import os
import time

# 指定目录路径
directory_path = r'G:\eclipse_workspace\real-time-robot\src\main\webapp\video\record'

for i in range(10000):
    # 检查目录是否存在
    if os.path.exists(directory_path):
        # 获取目录下的所有文件
        files = os.listdir(directory_path)

        # 遍历目录中的所有文件并删除它们
        for file_name in files:
            file_path = os.path.join(directory_path, file_name)

            # 检查是否为文件
            if os.path.isfile(file_path):



                model = YOLO("best.pt")
                results = model.predict(file_path, save=True, save_txt=False, classes=[0, 1, 2], conf=0.4)





                print(f"处理视频完成并删除文件：{file_path}")

                # 删除文件
                os.remove(file_path)
    else:
        print(f"目录不存在：{directory_path}")

    time.sleep(30)

