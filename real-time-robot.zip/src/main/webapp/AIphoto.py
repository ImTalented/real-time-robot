import os
from ultralytics import YOLO
import shutil
import time
import mysql.connector
from PIL import Image
from datetime import datetime

# 初始化 YOLO 模型
model = YOLO("best.pt")

# 输入文件夹路径，存放待探测的图片
input_folder = r'G:\eclipse_workspace\real-time-robot\src\main\webapp\image\captrue'

# 输出文件夹路径，存放识别出有物体存在的图片
output_folder = r'G:\eclipse_workspace\real-time-robot\src\main\webapp\image\photo'

current_directory = r'image\captrue'


db_config = {
    'host': 'localhost',  # 数据库主机
    'user': 'root',       # 数据库用户名
    'password': 'fsh12345',  # 数据库密码
    'database': 'javawebdb'  # 数据库名
}



# 初始化文件数量
num = -1;

for i in range(1000000):
    time.sleep(15)

    # 获取目录下的文件列表
    file_list = os.listdir(current_directory)
    # 统计文件个数
    file_count = len(file_list)

    if file_count != num:
        num = file_count
        try:
            # 建立数据库连接
            conn = mysql.connector.connect(**db_config)
            cursor = conn.cursor()

            # 遍历当前目录下的文件
            for filename in os.listdir(current_directory):
                if filename.endswith(('.jpg', '.jpeg', '.png', '.bmp', '.gif')):
                    file_path = os.path.join(current_directory, filename)
                    # 查询数据库中是否已存在相同的图片
                    sql_check = "SELECT COUNT(*) FROM photo WHERE src = %s"
                    val_check = (file_path.replace('\\', '/'),)
                    cursor.execute(sql_check, val_check)
                    result = cursor.fetchone()

                    if result[0] == 0:
                        # 遍历输入文件夹中的所有图片
                        for filename in os.listdir(input_folder):
                            if filename.endswith(('.jpg', '.jpeg', '.png', '.bmp', '.gif')):
                                input_image_path = os.path.join(input_folder, filename)

                                # 进行物体探测，并设置stream=True以避免内存问题
                                results = model.predict(input_image_path, save=True, save_txt=True, classes=[0, 1, 2], conf=0.6,
                                                        project=r'G:\eclipse_workspace\real-time-robot\src\main\webapp\image\photo',
                                                        name='result')

                        source_folder = output_folder
                        destination_folder = r'G:\eclipse_workspace\real-time-robot\src\main\webapp\image\photo\detected'

                        # 遍历源文件夹
                        for root, dirs, files in os.walk(source_folder):
                            for dir in dirs:
                                if dir.startswith("result"):
                                    result_folder = os.path.join(root, dir)
                                    labels_folder = os.path.join(result_folder, "labels")

                                    # 检查labels文件夹是否存在并包含txt文件
                                    if os.path.exists(labels_folder):
                                        txt_files = [f for f in os.listdir(labels_folder) if f.endswith(".txt")]
                                        if txt_files:
                                            # 如果labels文件夹包含txt文件，将result文件夹内的图片复制到目标文件夹
                                            for file in os.listdir(result_folder):
                                                if file.endswith(".jpg") or file.endswith(".png"):
                                                    source_file = os.path.join(result_folder, file)
                                                    destination_file = os.path.join(destination_folder, file)
                                                    shutil.copy2(source_file, destination_file)

        except mysql.connector.Error as err:
            print(f'数据库错误: {err}')
        finally:
            # 关闭数据库连接
            if conn.is_connected():
                cursor.close()
                conn.close()




